This DEMO font is for PERSONAL USE ONLY! 

ENGLISH:

By installing or using this font, you are agree to the Product Usage Agreement:

1. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use.

3. CONTACT ME before any Promotional or Commercial Use!

EMAIL SUPPORT:
nurfdesigns@gmail.com

-------------------

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use", atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font saya. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, atau Perusahaan/Korporasi.

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Menggunakan font ini untuk kepentingan Komersial -apapun bentuknya-TANPA IZIN dari saya, akan dikenakan biaya EXTENDED LICENSE.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi saya:
Email: nurfdesigns@gmail.com   

Paypal account for donation : paypal.me/nurfdesigns


Thank You
